function saluda() {

   return "¡Hola mundo!";

}

var frase = saluda();

console.log(frase); //Imprime aquí ¡Hola mundo!